#!/bin/sh
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  printf "Install Node.js 22 or newer from https://nodejs.org/ first.\n"
  exit 1
fi
node server/local.mjs
