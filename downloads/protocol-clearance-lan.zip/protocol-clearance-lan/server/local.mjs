import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { WebSocketServer } from 'ws';
import { CoopRoom } from './room.mjs';
import { BUILD_ID, NET_VERSION, MAX_PLAYERS, MAX_MESSAGE_BYTES, TICK_RATE, encode, decode, roomCode, validCode, cleanName } from '../src/net/protocol.js';

const ROOT=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const TYPES={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.ico':'image/x-icon'};
/** 静态文件白名单：同一端口提供游戏页面与三关平面图，孩子用局域网地址打开即可，无需第二个服务。
 *  只放行 index.html / floorplan*.html / src/ / node_modules/three/，仓库其它文件（测试、工具、文档、包元数据）不对外。 */
function serveStatic(req,res) {
  const url=new URL(req.url,'http://local');
  let raw;try{raw=decodeURIComponent(url.pathname);}catch{res.writeHead(400);res.end('Invalid path');return;}
  const rel=raw==='/'?'/index.html':raw;
  const allowedPath=rel==='/index.html'||/^\/floorplan\d*\.html$/.test(rel)
    ||rel.startsWith('/src/')||rel.startsWith('/node_modules/three/')
    ||rel==='/server/room.mjs'||rel==='/server/simulation.mjs'
    ||rel==='/downloads/protocol-clearance-lan.zip';
  if(!allowedPath||!/\.(html|js|mjs|css|json|png|jpg|svg|ico|zip)$/i.test(rel)){res.writeHead(404);res.end('Not found');return;}
  const file=path.normalize(path.join(ROOT,rel));
  if(!file.startsWith(ROOT+path.sep)){res.writeHead(404);res.end('Not found');return;}
  fs.readFile(file,(err,data)=>{
    if(err){res.writeHead(404);res.end('Not found');return;}
    if(path.extname(file)==='.zip'){res.setHeader('Content-Disposition','attachment; filename=protocol-clearance-lan.zip');res.setHeader('Content-Type','application/zip');}
    else res.setHeader('Content-Type',TYPES[path.extname(file).toLowerCase()]??'application/octet-stream');
    res.setHeader('Cache-Control','no-store');res.end(data);
  });
}

export function createCoopServer({ port=8787, host='0.0.0.0', now, tick=true }={}) {
  const rooms=new Map();
  const clients=new Set();
  const limits=new Map();
  // 局域网直连：不再限制来源，同 WiFi 内的任意设备都可连接本机后端。
  const allowed=()=>true;
  /** 房主若用 localhost 打开游戏，邀请链接必须换成局域网地址，否则队友点开连的是他自己的电脑。 */
  const lanAddresses=Object.entries(os.networkInterfaces()).flatMap(([name,list])=>(list??[])
    .filter(info=>info.family==='IPv4'&&!info.internal&&/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(info.address))
    .map(info=>({name,address:info.address})))
    .sort((a,b)=>Number(/vpn|virtual|vethernet|wsl|docker|tun|tap|tailscale|zerotier/i.test(a.name))-Number(/vpn|virtual|vethernet|wsl|docker|tun|tap|tailscale|zerotier/i.test(b.name)));
  const lanIPv4=lanAddresses[0]?.address??null;
  const server=http.createServer((req,res)=>{
    const origin=req.headers.origin;
    if(!allowed(origin)){res.writeHead(403);res.end();return;}
    res.setHeader('Access-Control-Allow-Origin',origin??'*');
    res.setHeader('Vary','Origin');
    res.setHeader('Access-Control-Allow-Methods','POST, GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers','Content-Type');
    if(req.method==='OPTIONS'){res.writeHead(204);res.end();return;}
    if(req.url==='/health'){res.setHeader('Content-Type','application/json');res.setHeader('Cache-Control','no-store');res.end(JSON.stringify({ok:true,build:BUILD_ID,version:NET_VERSION,features:{roomDirectory:true},lan:lanIPv4,lanAddresses}));return;}
    if(req.url==='/rooms'&&req.method==='POST') {
      const ip=req.socket.remoteAddress;const stamps=(limits.get(ip)??[]).filter(t=>Date.now()-t<60000);
      if(stamps.length>=10||rooms.size>=32){res.writeHead(429);res.end('创建过于频繁');return;}
      stamps.push(Date.now());limits.set(ip,stamps);
      let code;do{code=roomCode();}while(rooms.has(code));
      rooms.set(code,new CoopRoom(code,{now}));
      console.log(`[房间] ${code} 由 ${ip} 创建`);
      res.setHeader('Content-Type','application/json');res.setHeader('Cache-Control','no-store');res.end(JSON.stringify({code,lan:lanIPv4,lanAddresses}));return;
    }
    serveStatic(req,res);
  });
  const wss=new WebSocketServer({noServer:true,maxPayload:MAX_MESSAGE_BYTES,perMessageDeflate:false});
  server.on('upgrade',(req,socket,head)=>{
    const path=new URL(req.url,'http://local').pathname;
    const code=path.split('/')[2];
    if(!allowed(req.headers.origin)||!/^\/rooms\/[A-HJ-NP-Z2-9]{6}\/ws$/.test(path)||!validCode(code)||!rooms.has(code)){
      socket.end('HTTP/1.1 404 Not Found\r\n\r\n');return;
    }
    wss.handleUpgrade(req,socket,head,ws=>{ws.remoteAddress=req.socket.remoteAddress;wss.emit('connection',ws,rooms.get(code));});
  });
  wss.on('connection',(ws,room)=>{
    clients.add(ws);let member=null;let budget=0,windowAt=Date.now();
    const send=(msg)=>{if(ws.readyState===1&&ws.bufferedAmount<512000)ws.send(encode(msg));};
    const timeout=setTimeout(()=>{if(!member)ws.close(1008,'请先握手');},5000);
    ws.on('message',(data,binary)=>{
      if(binary)return ws.close(1003,'只接受文本消息');
      if(Date.now()-windowAt>1000){budget=0;windowAt=Date.now();}
      if(++budget>90)return ws.close(1008,'消息过于频繁');
      let msg;try{msg=decode(data.toString());}catch{return ws.close(1007,'无效消息');}
      if(!member) {
        if(msg.type!=='hello'||msg.version!==NET_VERSION||msg.build!==BUILD_ID){send({type:'error',message:'版本不一致，请刷新游戏'});return ws.close(1008);}
        try {
          if(msg.id&&!/^[a-f0-9-]{36}$/.test(msg.id))throw new Error('凭据无效');
          if(msg.id&&!/^[a-f0-9-]{36}$/.test(msg.token))throw new Error('凭据无效');
          const id=msg.id??crypto.randomUUID();
          member=room.join({id,token:msg.id?msg.token:crypto.randomUUID(),name:cleanName(msg.name),recovery:msg.recovery},send);
          clearTimeout(timeout);
          console.log(`[加入] ${room.code} ← ${ws.remoteAddress}（${member.name}）`);
        } catch(err){send({type:'error',message:err.message});ws.close(1008);}
      } else {try{room.receive(member.id,msg,send);}catch{send({type:'error',message:'服务器拒绝了这次操作'});}}
    });
    ws.on('close',()=>{clearTimeout(timeout);clients.delete(ws);if(member){console.log(`[离开] ${room.code} — ${ws.remoteAddress}（${member.name}）`);room.disconnect(member.id,send);}});
    ws.on('error',()=>ws.close());
  });
  let count=0,lastTick=performance.now();
  const timer=tick?setInterval(()=>{
    const nowTick=performance.now(),dt=Math.min(.1,(nowTick-lastTick)/1000);lastTick=nowTick;
    for(const [code,room] of rooms){
      if(Date.now()>room.expiresAt){room.broadcast({type:'error',message:'房间已过期'});room.dispose();rooms.delete(code);continue;}
      room.advance(dt);if(count%3===0)room.snapshots();
    }
    count++;
  },1000/TICK_RATE):null;
  const ready=new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,host,()=>resolve(server.address()));});
  return {server,rooms,ready,close:async()=>{if(timer)clearInterval(timer);for(const ws of clients)ws.terminate();for(const r of rooms.values())r.dispose();wss.close();await new Promise(r=>server.close(r));}};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
  const app=createCoopServer({port:Number(process.env.PORT??8787)});
  let addr;
  try{addr=await app.ready;}catch(err){console.error(err.code==='EADDRINUSE'?'端口已被占用：请关闭之前启动的服务，或设置 PORT 使用其他端口。':`无法启动局域网服务：${err.message}`);process.exit(1);}
  const port=addr.port;
  const lan=[];
  for(const list of Object.values(os.networkInterfaces()))for(const info of list??[]){
    if(info.family==='IPv4'&&!info.internal)lan.push(info.address);
  }
  console.log(`肃清协议联机服务已启动 (${BUILD_ID})`);
  console.log(`  本机：http://localhost:${port}/`);
  for(const ip of lan)console.log(`  局域网：http://${ip}:${port}/  ← 同一 WiFi 的队友用这个地址`);
  if(!lan.length)console.log('  未检测到局域网地址：请确认已连接 WiFi 或网线');
  console.log('  所有人打开同一局域网网址：房主点「创建房间」，队友输入房间码点「加入好友」。');
  console.log('  若队友打不开：在 Windows 防火墙里允许 Node.js 的“专用网络”访问。');
  process.on('SIGINT',()=>{void app.close().then(()=>process.exit());});
}
